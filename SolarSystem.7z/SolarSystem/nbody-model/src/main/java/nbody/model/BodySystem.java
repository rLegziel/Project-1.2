package nbody.model;


import javafx.animation.Timeline;

import java.sql.Time;
import java.util.*;

import static nbody.model.CelestialBody.EARTH;
import static nbody.model.CelestialBody.SATURN;

public class BodySystem {
    private static final int SEC_IN_MINUTE = 60;
    private static final int SEC_IN_HOUR = SEC_IN_MINUTE * 60;
    private static final int SEC_IN_DAY = SEC_IN_HOUR * 24;
    private static final int SEC_IN_YEAR = 31556926;
    private long elapsedSeconds = 0;
    public double startingDistance = 1.4E+10;
    public Body chosenOne;
    public String dateOfImpact;

    //8.862395206670821E8
    //2.223667170921659E9
    // from titan 3.2670147095408136E8
    //6.874331296673225E8
    // 6.874331296673225E8
    //4.822473458108047E7

    //private long firstLaunch =185238000  ;
    private long firstLaunch = 86400;
    private long intervalTime = (long) SEC_IN_DAY/8;  //how long between launches
    private long interval = firstLaunch;

    private long perfectTime; //change this to date format once we can

    private long minDistance = Long.MAX_VALUE;
    private int minDistanceProbe = -1;

    private boolean print = true;

    Timeline timeline;

    public double currentDistance;

    private int probesNum = 1; //number of probes we send at a time
    private int probesLimit =5 ; //limit the number of probes we send
    private ArrayList<Body> probesList = new ArrayList<>();//stores all the probes we launch
    private ArrayList<Probe> realProbesList = new ArrayList<>();
    private ArrayList<Double> minDistancesList = new ArrayList<>();
    ArrayList<Long> launchTimesList = new ArrayList<>();//stores the times in which we launch the probes, we should change this to a date in the future

    private List<Body> bodies;

    public BodySystem() {
        bodies = new ArrayList<>();
    }

    public List<Body> getBodies() {
        return bodies;
    }

    public void addBody(Body body) {
        bodies.add(body);
    }

    public double update(double timeSlice, Timeline timeline) {
        this.timeline = timeline;
        // reset acceleration so we can accumulate acceleration due to gravitation from all bodies
        bodies.stream().forEach(i -> i.resetAcceleration()) ;

        // add gravitation force to each body from each body
        for (int i = 0; i < bodies.size(); i++) {
            Body current = bodies.get(i);
            for (int j = i+1; j < bodies.size(); j++) {
                Body other = bodies.get(j);
                //System.out.println(bodies.get(1).getAcceleration().toString());
                current.addAccelerationByGravityForce(other);
                other.addAccelerationByGravityForce(current);
                //current.Thruster();
                //other.Thruster();
            }
        }





        if(elapsedSeconds == interval &&  probesList.size() <=probesLimit){
//        if(elapsedSeconds == interval && probesList.size() <= probesLimit) {
            launchNewProbe();


        }

        /**
         * this change the direction of the probe on everytime the model gets updated
         * we still have to find a way to calculate how we are going to use the engine
         * if you don't see the probes the acceleration is probably too fast and you have to zoom out or change the size of the vector in the body class
         */
        if (elapsedSeconds > interval){
            for (int i = 0; i<probesList.size();i++){
                probesList.get(i).thrusterRight();
            }
        }

        // update velocity and location for each body
        bodies.stream().forEach(i -> i.updateVelocityAndLocation(timeSlice));
        elapsedSeconds += timeSlice;
        //157786200


        if(elapsedSeconds > interval){
            //System.out.println("probe" + probesList.get(0).location.toString());
            //System.out.println("saturn" + SATURN.location.toString());
            //System.out.println("earth" + EARTH.location.toString());

            double x1 = probesList.get(0).location.x;
            double x2 = SATURN.location.x;
            double y1 = probesList.get(0).location.x;
            double y2 = SATURN.location.y;

            currentDistance = bodies.get(bodies.size()-1).location.probeDistance(bodies.get(6).location);

            //System.out.println(bodies.get(bodies.size()-1).location.probeDistance(bodies.get(6).location));
//            System.out.println(minDistance);
        }

        //SEC_IN_YEAR * 7.82
        if(elapsedSeconds > SEC_IN_YEAR * 7.83 && print){
            check1();
            //System.out.println(minDistance + " " + minDistanceProbe);
            for(double d: minDistancesList){
//                System.out.println(d + " hahahahaha " + minDistancesList.indexOf(d));
            }
            print = false;
            //timeline.pause();
        }

        return timeSlice;
    }

    /**
     * launches a new probe, with earth's location. in this method you can choose its velocity, mass etc.
     */
    private void launchNewProbe(){



        //info for the probe
        double radius = 100; //in meters
        double mass = 5000; //in kg

        //launch multiple probes at same time but different velocities
        for(int x = 0; x <= probesNum-1; x++){


        }

        Vector3D location = EARTH.getAsBody().location;//bodies.get(3).getLocation();//EARTH.getAsBody().location;//because we are always launching from same site
        Vector3D velocity = EARTH.getAsBody().velocity; //bodies.get(3).getVelocity();//EARTH.getAsBody().velocity; //just as a reference for now, change to something more realistic

        Vector3D v = new Vector3D(6371.008E+3,0,0);
        v.add(bodies.get(3).location);

        // creates random scalars for probes, for optimization purposes.
        double rangeMax = 2.75;
        double rangeMin = 1.5;
        Random rand = new Random();
        double scalarX = rangeMin +(rangeMax-rangeMin)*rand.nextDouble();
        double scalarY = rangeMin +(rangeMax-rangeMin)*rand.nextDouble();

        location = v;

        // X and Y velocity of the probe.
        //velocity.x = velocity.x*1.978;
        //velocity.y = velocity.y*1.745;
        velocity.x = 0;
        velocity.y = 0;
        velocity.z = 0;



        Body probe = new Body(location,velocity,radius,mass);

        Probe rProbe = new Probe(location,velocity,radius,mass,"prob" + probesList.size(),elapsedSeconds,
                velocity.x,velocity.y);

        realProbesList.add(rProbe);
        probesList.add(probe);
        minDistancesList.add(Double.MAX_VALUE);
        probe.name = "probe" + probesList.indexOf(probe);
        System.out.println(probe.name + " launched on " + getElapsedTimeAsString());
        launchTimesList.add(elapsedSeconds);

        addBody(probe);
//        System.out.println("probe " + probesList.indexOf(probe) + " launched at " + elapsedSeconds +
//                " scalarX: " + scalarX + " scalarY: " + scalarY) ;

        //change this so it doesn't send multiple probes at one time
        interval+=intervalTime;
    }


    /**
     * checks the distance between each probe and titan, will print the probe that gets closest to titan.
     */
    public void check1(){
        for(Body probe:probesList){
            double distance =  probe.location.probeDistance(bodies.get(10).location); // location of the probe, distance to saturn
            if (distance<startingDistance){
                chosenOne = probe;
                System.out.println(probe);
                System.out.println(bodies.get(10));
                startingDistance = distance;
                System.out.println(" The minimum distance is(in meters) : " + startingDistance);
                dateOfImpact = getElapsedTimeAsString();
                System.out.println(dateOfImpact);
                System.out.println(launchTimesList);

            }




        }
    }


    public Optional<Body> getBody(String name) {
        return bodies.stream().filter(i -> i.name.equals(name)).findFirst();
    }

    public String getElapsedTimeAsString() {
        long years = elapsedSeconds / SEC_IN_YEAR;
        long days = (elapsedSeconds % SEC_IN_YEAR) / SEC_IN_DAY;
        long hours = ( (elapsedSeconds % SEC_IN_YEAR) % SEC_IN_DAY) / SEC_IN_HOUR;
        long minutes = ( ((elapsedSeconds % SEC_IN_YEAR) % SEC_IN_DAY) % SEC_IN_HOUR) / SEC_IN_MINUTE;
        long seconds = ( ((elapsedSeconds % SEC_IN_YEAR) % SEC_IN_DAY) % SEC_IN_HOUR) % SEC_IN_MINUTE;
        return String.format("Years:%08d, Days:%03d, Hours:%02d, Minutes:%02d, Seconds:%02d", years, days, hours, minutes, seconds);
    }

    public long getElapsedTime(){
        return elapsedSeconds;
    }

}
