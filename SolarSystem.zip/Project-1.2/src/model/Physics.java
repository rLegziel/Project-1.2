package model;


//if we not gonna use it we should delete it
public final class Physics {
    private Physics() {}

    /** Universal gravity constant */
    public static final double G = 6.67300E-11;
    public static final double gTitan = 1.352;

}
