package nbody.model;

public class LandingSim {


}
