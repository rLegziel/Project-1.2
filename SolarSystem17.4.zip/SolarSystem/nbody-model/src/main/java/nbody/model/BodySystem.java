package nbody.model;


import javafx.animation.Timeline;

import java.sql.Time;
import java.util.*;

import static nbody.model.CelestialBody.*;

public class BodySystem {
    private static final int SEC_IN_MINUTE = 60;
    private static final int SEC_IN_HOUR = SEC_IN_MINUTE * 60;
    private static final int SEC_IN_DAY = SEC_IN_HOUR * 24;
    private static final int SEC_IN_YEAR = 31556926;
    private long elapsedSeconds = 0;
    public double startingDistance = 1.4E+10;
    public Body chosenOne;
    public String dateOfImpact;
    public int counter = 0;
    public ArrayList<Double> xLocations = new ArrayList<>();
    ArrayList<Double> yLocations =  new ArrayList<>();
    public boolean flag = false;
    public double probeSlope;
    public double vectorS;
    public boolean nextFlag =true;


    //8.862395206670821E8
    //2.223667170921659E9
    // from titan 3.2670147095408136E8
    //6.874331296673225E8
    // 6.874331296673225E8
    //4.822473458108047E7

    private long firstLaunch =(SEC_IN_YEAR+(SEC_IN_HOUR*5))*2 ;
    private long intervalTime = (long) SEC_IN_DAY/4;  //how long between launches
    private long interval = firstLaunch;

    private long perfectTime; //change this to date format once we can

    private long minDistance = Long.MAX_VALUE;
    private int minDistanceProbe = -1;

    private boolean print = true;

    Timeline timeline;

    public double currentDistance;

    private int probesNum = 1; //number of probes we send at a time
    private int probesLimit =1 ; //limit the number of probes we send
    private ArrayList<Body> probesList = new ArrayList<>();//stores all the probes we launch
    private ArrayList<Probe> realProbesList = new ArrayList<>();
    private ArrayList<Double> minDistancesList = new ArrayList<>();
    ArrayList<Long> launchTimesList = new ArrayList<>();//stores the times in which we launch the probes, we should change this to a date in the future

    private List<Body> bodies;

    public BodySystem() {
        bodies = new ArrayList<>();
    }

    public List<Body> getBodies() {
        return bodies;
    }

    public void addBody(Body body) {
        bodies.add(body);
    }

    public double update(double timeSlice, Timeline timeline) {
        this.timeline = timeline;
        // reset acceleration so we can accumulate acceleration due to gravitation from all bodies
        bodies.stream().forEach(i -> i.resetAcceleration()) ;

        // add gravitation force to each body from each body
        for (int i = 0; i < bodies.size(); i++) {
            Body current = bodies.get(i);
            for (int j = i+1; j < bodies.size(); j++) {
                Body other = bodies.get(j);
                current.addAccelerationByGravityForce(other);
                other.addAccelerationByGravityForce(current);
            }
        }
        // update velocity and location for each body
        bodies.stream().forEach(i -> i.updateVelocityAndLocation(timeSlice));
        elapsedSeconds += timeSlice;
        //157786200

        if(elapsedSeconds >= interval-timeSlice &&elapsedSeconds % interval <=timeSlice &&  probesList.size() <=probesLimit){
//        if(elapsedSeconds == interval && probesList.size() <= probesLimit) {
            launchNewProbe();
            double currentLaunchTime = elapsedSeconds;


        }

        if(elapsedSeconds > interval){
            double distance =  probesList.get(0).location.probeDistance(bodies.get(10).location);
//            System.out.println(distance +" is the distance variable ");

                double x1 = probesList.get(0).location.x;
                double x2 = TITAN.location.x;
                double y1 = probesList.get(0).location.y;
                double y2 = TITAN.location.y;
                check1();
//                currentDistance = bodies.get(bodies.size() - 2).location.probeDistance(bodies.get(6).location);
//            System.out.println(startingDistance +" is the startingDistance variable");

                 xLocations.add(probesList.get(0).location.x);
                 yLocations.add(probesList.get(0).location.y);
                 counter++;
                 if (xLocations.size() > 2) {
//                     double slopeX = xLocations.get(counter-1) - xLocations.get(counter-2);
//                     double slopeY = yLocations.get(counter-1) - yLocations.get(counter-2);
//                     double slopeU = slopeX/slopeY;
////                     System.out.println("slope x is " + slopeX);
////                     System.out.println("slope y is "+ slopeY);
////                     System.out.println("the slope is actually " + slopeU);
//                     double slopeVectorX = xLocations.get(counter-1) - x2;
//                     double slopeVectorY = yLocations.get(counter-1) - y2;
//                     double slopeVector = slopeVectorX/slopeVectorY;
//                     System.out.println(slopeVector + " is the slopevector");
//                     vectorS = (0-1)*slopeVector;
//                     probeSlope = slopeU;
                     flag = true;
                 }
                 if(flag){
                     double changeX = (bodies.get(10).location.x - probesList.get(0).location.x);
                     double changeY = (bodies.get(10).location.y - probesList.get(0).location.y);
                     probesList.get(0).setVelocityX(changeX);
                     probesList.get(0).setVelocityY(changeY);
                 }
//                 if (flag){
//                     if (vectorS<0 && probeSlope > 0 || vectorS> 0 && probeSlope< 0){
//                         probesList.get(0).velocity.x = probesList.get(0).velocity.x*0.99;
//                         probesList.get(0).velocity.y = probesList.get(0).velocity.y*(0-1.1);
//                         check1();
//                          distance =  probesList.get(0).location.probeDistance(bodies.get(10).location);
//                     }
////                     System.out.println("vector slope is " + vectorS);
//                     if (probeSlope > vectorS  ){
//                         probesList.get(0).velocity.y = probesList.get(0).velocity.y*0.99;
//                         check1();
//                         distance =  probesList.get(0).location.probeDistance(bodies.get(10).location);
//                     }else if(vectorS>probeSlope){
//                         probesList.get(0).velocity.y = probesList.get(0).velocity.y*1.15;
//                         distance =  probesList.get(0).location.probeDistance(bodies.get(10).location);
//                         check1();
//                     }
//                     if(distance<2.822789155825462E9 + 120000 && 8.139232644900228E15 >probesList.get(0).velocity.x ){
//                         probesList.get(0).velocity.y = probesList.get(0).velocity.y*0.8;
//                         probesList.get(0).velocity.x = probesList.get(0).velocity.x*0.99;
//                         check1();
//                         flag = false;
//                         System.out.println("our current yVel is " + probesList.get(0).velocity.y + "the xVel is " +probesList.get(0).velocity.x );
//                         distance =  probesList.get(0).location.probeDistance(bodies.get(10).location);
//                         if(distance <= 75000 ){
//                             System.out.println("are we here?");
//                             probesList.get(0).velocity.y = probesList.get(0).velocity.y*1;
//                             probesList.get(0).velocity.x = probesList.get(0).velocity.x*1;
//                         }
//                     }
//                     if(distance <= 2.9148533860822296E9 && nextFlag){
////                         System.out.println(" or are we here?");
//                         if(nextFlag == true) {
//                             System.out.println("please dont");
//                             probesList.get(0).velocity.y = probesList.get(0).velocity.y * (0-0.95);
//                             probesList.get(0).velocity.x = probesList.get(0).velocity.x * 1.0001;
//                             distance =  probesList.get(0).location.probeDistance(bodies.get(10).location);
//                             nextFlag = false;
//                             check1();
//                         }else{
////                             System.out.println("Yes?");
//                             probesList.get(0).velocity.y = probesList.get(0).velocity.y * 0.999999;
//                             probesList.get(0).velocity.x = probesList.get(0).velocity.x * 0.999999;
//                             distance =  probesList.get(0).location.probeDistance(bodies.get(10).location);
//                             check1();
//
//                         }
//                     }
//                 }
//            if(distance <= 2.8801341408057547E9){
//                probesList.get(0).velocity.y = probesList.get(0).velocity.y*0.95;
//                probesList.get(0).velocity.x = probesList.get(0).velocity.x*0.95;
//            }


        }

        //SEC_IN_YEAR * 7.82
        if(elapsedSeconds > SEC_IN_YEAR * 7.83 && print){
            check1();
            //System.out.println(minDistance + " " + minDistanceProbe);
            for(double d: minDistancesList){
            }
            print = false;
            //timeline.pause();
        }


        return timeSlice;
    }

    /**
     * launches a new probe, with earth's location. in this method you can choose its velocity, mass etc.
     */
    private void launchNewProbe(){



        //info for the probe
        double radius = 100; //in meters
        double mass = 5000; //in kg

        //launch multiple probes at same time but different velocities
        for(int x = 0; x <= probesNum-1; x++){


        }

        Vector3D location = EARTH.getAsBody().location;//bodies.get(3).getLocation();//EARTH.getAsBody().location;//because we are always launching from same site
        Vector3D velocity = EARTH.getAsBody().velocity; //bodies.get(3).getVelocity();//EARTH.getAsBody().velocity; //just as a reference for now, change to something more realistic

        Vector3D v = new Vector3D(6371.008E+3,0,0);
        v.add(bodies.get(3).location);

        // creates random scalars for probes, for optimization purposes.
        double rangeMax = 2.75;
        double rangeMin = 1.5;
        Random rand = new Random();
        double scalarX = rangeMin +(rangeMax-rangeMin)*rand.nextDouble();
        double scalarY = rangeMin +(rangeMax-rangeMin)*rand.nextDouble();

        location = v;

        // X and Y velocity of the probe.
        velocity.x = velocity.x*1.9;
        velocity.y = velocity.y*1.85;



        Body probe = new Body(location,velocity,radius,mass);

        Probe rProbe = new Probe(location,velocity,radius,mass,"prob" + probesList.size(),elapsedSeconds,
                velocity.x,velocity.y);

        realProbesList.add(rProbe);
        probesList.add(probe);
        minDistancesList.add(Double.MAX_VALUE);
        probe.name = "probe" + probesList.indexOf(probe);
        System.out.println(probe.name + " launched on " + getElapsedTimeAsString());
        launchTimesList.add(elapsedSeconds);
        double currnetLaunchTime = elapsedSeconds;
        addBody(probe);
//        System.out.println("probe " + probesList.indexOf(probe) + " launched at " + elapsedSeconds +
//                " scalarX: " + scalarX + " scalarY: " + scalarY) ;

        //change this so it doesn't send multiple probes at one time
        interval+=intervalTime;


    }


    /**
     * checks the distance between each probe and titan, will print the probe that gets closest to titan.
     */
    public void check1(){
        for(Body probe:probesList){
            double distance =  probe.location.probeDistance(bodies.get(10).location); // location of the probe, distance to saturn
            if (distance<startingDistance){
                chosenOne = probe;
                System.out.println(probe);
                System.out.println(bodies.get(10));
                startingDistance = distance;
                System.out.println(" The minimum distance is(in meters) : " + distance);
                dateOfImpact = getElapsedTimeAsString();
                double velocityY = probe.velocity.y;
                double velocityX = probe.velocity.x;
                System.out.println(velocityX +" is the x velocity " + velocityY + " is the y velocity at closest approach");

                System.out.println(dateOfImpact);
                System.out.println(launchTimesList);

            }




        }
    }


    public Optional<Body> getBody(String name) {
        return bodies.stream().filter(i -> i.name.equals(name)).findFirst();
    }

    public String getElapsedTimeAsString() {
        long years = elapsedSeconds / SEC_IN_YEAR;
        long days = (elapsedSeconds % SEC_IN_YEAR) / SEC_IN_DAY;
        long hours = ( (elapsedSeconds % SEC_IN_YEAR) % SEC_IN_DAY) / SEC_IN_HOUR;
        long minutes = ( ((elapsedSeconds % SEC_IN_YEAR) % SEC_IN_DAY) % SEC_IN_HOUR) / SEC_IN_MINUTE;
        long seconds = ( ((elapsedSeconds % SEC_IN_YEAR) % SEC_IN_DAY) % SEC_IN_HOUR) % SEC_IN_MINUTE;
        return String.format("Years:%08d, Days:%03d, Hours:%02d, Minutes:%02d, Seconds:%02d", years, days, hours, minutes, seconds);
    }

    public long getElapsedTime(){
        return elapsedSeconds;
    }

    public void vectorSlope(ArrayList<Double> xloc,ArrayList<Double> yloc){
        double xTitan = bodies.get(10).location.x;
        double yTitan = bodies.get(10).location.y;
        double xProbe = xloc.get(xloc.size()-1);
        double yProbe = yloc.get(yloc.size()-1);
        double slope = (xProbe-xTitan)/(yProbe-yTitan);
        vectorS = slope;
    }

    public void updateProbeSlope(ArrayList<Double> xloc,ArrayList<Double> yloc){
        double xProbe1 = xloc.get(xloc.size()-1);
        double yProbe1 = yloc.get(yloc.size()-1);
        double xProbe2 = xloc.get(xloc.size()-2);
        double yProbe2 = yloc.get(yloc.size()-2);
        double slope = (xProbe1-xProbe2)/(yProbe1-yProbe2);
        probeSlope = slope;
    }

}
